return
{
	-- This table contains a list of vertex data
	-- (using an array)
	vertex =
	{
		{0.0, 0.0, 0.0},
		{-1.0, -1.0, 0.0},
		{0.0, -1.0, 0.0},
		{-1.0, 0.0, 0.0}
	},

	-- This table contains a list of index data
	-- (using an array)
	index = {
		0, 3, 1, 0, 1, 2
	}
}